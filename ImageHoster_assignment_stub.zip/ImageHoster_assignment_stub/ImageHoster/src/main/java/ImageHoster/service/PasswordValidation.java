package ImageHoster.service;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import org.springframework.stereotype.Service;

@Service
public class PasswordValidation {
	
	
	public boolean validatePassword(String password) {
		
		boolean doesPasswordPassCriteria =Boolean.FALSE;
		
		byte[] ascii = password.getBytes(StandardCharsets.US_ASCII); 
		String[] asciiString = Arrays.toString(ascii).split(","); 

		for(String charValue:asciiString) {
			doesPasswordPassCriteria =Boolean.TRUE;
			if(!(Integer.parseInt(charValue) >= 32 || Integer.parseInt(charValue)<=127)) {
				doesPasswordPassCriteria =Boolean.FALSE;
				break;
			}}
		return doesPasswordPassCriteria;
	}

}
